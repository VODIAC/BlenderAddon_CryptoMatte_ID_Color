bl_info = {
    "name": "CryptoMatte ID Color",
    "author": "61+",
    "version": (1, 0, 0),
    "blender": (5, 1, 1),
    "location": "Compositor > Sidebar > Tool",
    "description": "Generate real-time ID color compositor nodes using Cryptomatte.",
    "category": "Compositing",
}

import colorsys
import random
import sys

import bpy
from bpy.props import BoolProperty, FloatVectorProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel


OBJECT_GROUP_NAME = "ObjectID"
MATERIAL_GROUP_NAME = "Material ID"
ID_INPUT_NAME = "ID input"
OUTPUT_NAME = "Image"

SHORTCUT_TARGETS = (
    ("object_id", "Object ID", "ALT O", "object_id.create", "OBJECT_DATA"),
    ("material_id", "Material ID", "ALT M", "object_id.create_material", "MATERIAL_DATA"),
    ("change_id", "Change ID", "ALT PERIOD", "object_id.change", "COLOR"),
    ("random_id", "Random ID", "ALT COMMA", "object_id.random", "FILE_REFRESH"),
)
SHORTCUT_TARGET_IDS = {item[0] for item in SHORTCUT_TARGETS}
SHORTCUT_DEFAULTS = {item[0]: item[2] for item in SHORTCUT_TARGETS}
SHORTCUT_ICONS = {item[0]: item[4] for item in SHORTCUT_TARGETS}

SHORTCUT_KEYMAPS = (
    ("Node Editor", "NODE_EDITOR"),
    ("Object Mode", "EMPTY"),
)

RENDERABLE_TYPES = {
    "MESH",
    "CURVE",
    "SURFACE",
    "META",
    "FONT",
    "VOLUME",
    "GPENCIL",
    "GREASEPENCIL",
}

addon_keymaps = []


def _socket_by_name(sockets, names, fallback_index=None):
    for name in names:
        socket = sockets.get(name)
        if socket:
            return socket

    wanted = {name.lower() for name in names}
    for socket in sockets:
        if socket.name.lower() in wanted or socket.identifier.lower() in wanted:
            return socket

    if fallback_index is not None and len(sockets) > fallback_index:
        return sockets[fallback_index]

    return None


def _visible_renderable_objects(context):
    view_layer = context.view_layer
    objects = []

    for obj in view_layer.objects:
        if obj.type not in RENDERABLE_TYPES or obj.hide_render:
            continue

        try:
            visible = obj.visible_get(view_layer=view_layer)
        except TypeError:
            visible = obj.visible_get()

        if visible:
            objects.append(obj)

    objects.sort(key=lambda item: item.name.lower())
    return objects


def _visible_materials(context):
    materials = {}
    for obj in _visible_renderable_objects(context):
        for slot in obj.material_slots:
            material = slot.material
            if material:
                materials[material.name] = material

    return [materials[name] for name in sorted(materials.keys(), key=str.lower)]


def _auto_color(index, total):
    if total <= 0:
        return (1.0, 1.0, 1.0, 1.0)

    red, green, blue = colorsys.hsv_to_rgb(index / total, 1.0, 1.0)
    return (red, green, blue, 1.0)


def _ensure_group_socket(group, name, in_out, socket_type="NodeSocketColor"):
    if hasattr(group, "interface"):
        return group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)

    if in_out == "INPUT":
        return group.inputs.new(socket_type, name)

    return group.outputs.new(socket_type, name)


def _ensure_output_socket(tree, name, socket_type="NodeSocketColor"):
    if hasattr(tree, "interface"):
        for item in tree.interface.items_tree:
            if item.item_type == "SOCKET" and item.in_out == "OUTPUT" and item.name == name:
                return item
        return tree.interface.new_socket(name=name, in_out="OUTPUT", socket_type=socket_type)

    socket = tree.outputs.get(name)
    if socket:
        return socket

    return tree.outputs.new(socket_type, name)


def _set_interface_default(group, socket_name, value):
    if not hasattr(group, "interface"):
        socket = group.inputs.get(socket_name)
        if socket and hasattr(socket, "default_value"):
            socket.default_value = value
        return

    for item in group.interface.items_tree:
        if item.item_type == "SOCKET" and item.name == socket_name:
            if hasattr(item, "default_value"):
                item.default_value = value
            return


def _scene_compositor_tree(scene):
    if hasattr(scene, "node_tree"):
        return scene.node_tree

    return getattr(scene, "compositing_node_group", None)


def _ensure_scene_compositor_tree(scene):
    if hasattr(scene, "node_tree"):
        scene.use_nodes = True
        return scene.node_tree

    tree = getattr(scene, "compositing_node_group", None)
    if tree:
        return tree

    tree = bpy.data.node_groups.new("Scene Compositing", "CompositorNodeTree")
    scene.compositing_node_group = tree
    scene.use_nodes = True
    return tree


def _remove_old_group(scene, group_name):
    tree = _scene_compositor_tree(scene)

    if tree:
        for node in list(tree.nodes):
            if node.bl_idname == "CompositorNodeGroup" and node.node_tree and node.node_tree.name == group_name:
                tree.nodes.remove(node)

    group = bpy.data.node_groups.get(group_name)
    if group:
        bpy.data.node_groups.remove(group, do_unlink=True)


def _configure_cryptomatte_node(node, scene, view_layer, matte_name, layer_name):
    node.label = matte_name

    for attr_name, attr_value in (
        ("scene", scene),
        ("source", "RENDER"),
        ("layer_name", layer_name),
        ("matte_id", matte_name),
        ("layer", view_layer.name),
    ):
        try:
            setattr(node, attr_name, attr_value)
        except Exception:
            pass


def _build_id_group(context, group_name, id_names, layer_name):
    scene = context.scene
    view_layer = context.view_layer
    group = bpy.data.node_groups.new(group_name, "CompositorNodeTree")
    total = len(id_names)

    _ensure_group_socket(group, ID_INPUT_NAME, "INPUT", "NodeSocketColor")
    for index, id_name in enumerate(id_names):
        _ensure_group_socket(group, id_name, "INPUT", "NodeSocketColor")
        _set_interface_default(group, id_name, _auto_color(index, total))
    _ensure_group_socket(group, OUTPUT_NAME, "OUTPUT", "NodeSocketColor")

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.location = (-850, 0)
    group_output = nodes.new("NodeGroupOutput")
    group_output.location = (520, 0)
    group_output.is_active_output = True

    id_output = _socket_by_name(group_input.outputs, [ID_INPUT_NAME], 0)
    final_image = None

    for index, id_name in enumerate(id_names):
        y = -index * 210

        crypto = nodes.new("CompositorNodeCryptomatteV2")
        crypto.location = (-540, y)
        _configure_cryptomatte_node(crypto, scene, view_layer, id_name, layer_name)

        set_alpha = nodes.new("CompositorNodeSetAlpha")
        set_alpha.location = (-180, y)

        crypto_image_input = _socket_by_name(crypto.inputs, ["Image"], 0)
        crypto_matte_output = _socket_by_name(crypto.outputs, ["Matte"], 1)
        color_output = _socket_by_name(group_input.outputs, [id_name])
        set_alpha_image_input = _socket_by_name(set_alpha.inputs, ["Image"], 0)
        set_alpha_alpha_input = _socket_by_name(set_alpha.inputs, ["Alpha"], 1)
        set_alpha_image_output = _socket_by_name(set_alpha.outputs, ["Image"], 0)

        if id_output and crypto_image_input:
            links.new(id_output, crypto_image_input)
        if color_output and set_alpha_image_input:
            links.new(color_output, set_alpha_image_input)
        if crypto_matte_output and set_alpha_alpha_input:
            links.new(crypto_matte_output, set_alpha_alpha_input)

        if not final_image:
            final_image = set_alpha_image_output
            continue

        alpha_over = nodes.new("CompositorNodeAlphaOver")
        alpha_over.location = (150, y + 105)
        background_input = _socket_by_name(alpha_over.inputs, ["Background"], 0)
        foreground_input = _socket_by_name(alpha_over.inputs, ["Foreground"], 1)
        factor_input = _socket_by_name(alpha_over.inputs, ["Factor", "Fac"], 2)

        if factor_input and hasattr(factor_input, "default_value"):
            factor_input.default_value = 1.0

        if final_image and background_input:
            links.new(final_image, background_input)
        if set_alpha_image_output and foreground_input:
            links.new(set_alpha_image_output, foreground_input)
        final_image = alpha_over.outputs[0]

    output_input = _socket_by_name(group_output.inputs, [OUTPUT_NAME], 0)
    if final_image and output_input:
        links.new(final_image, output_input)

    return group


def _find_or_create_node(tree, bl_idname, label, location):
    for node in tree.nodes:
        if node.bl_idname == bl_idname:
            return node

    node = tree.nodes.new(bl_idname)
    node.label = label
    node.location = location
    return node


def _ensure_render_layer_node(context, tree):
    node = _find_or_create_node(tree, "CompositorNodeRLayers", "Render Layers", (-580, 160))
    node.scene = context.scene

    try:
        node.layer = context.view_layer.name
    except Exception:
        pass

    return node


def _crypto_socket(render_layer_node, socket_name):
    socket = _socket_by_name(render_layer_node.outputs, [socket_name])
    if socket:
        return socket

    prefix = socket_name[:-2]
    for candidate in render_layer_node.outputs:
        if candidate.name.startswith(prefix):
            return candidate

    return None


def _add_group_node_and_links(context, group, crypto_socket_name, location_y):
    tree = _ensure_scene_compositor_tree(context.scene)
    render_layer = _ensure_render_layer_node(context, tree)

    group_node = tree.nodes.new("CompositorNodeGroup")
    group_node.node_tree = group
    group_node.name = group.name
    group_node.label = group.name
    group_node.location = (-60, location_y)

    crypto_socket = _crypto_socket(render_layer, crypto_socket_name)
    id_input = _socket_by_name(group_node.inputs, [ID_INPUT_NAME], 0)
    if crypto_socket and id_input:
        tree.links.new(crypto_socket, id_input)

    _ensure_output_socket(tree, OUTPUT_NAME)
    group_output_node = _find_or_create_node(tree, "NodeGroupOutput", "Group Output", (380, 210))
    viewer = _find_or_create_node(tree, "CompositorNodeViewer", "Viewer", (380, 0))

    group_output = _socket_by_name(group_node.outputs, [OUTPUT_NAME], 0)
    output_input = _socket_by_name(group_output_node.inputs, [OUTPUT_NAME], 0)
    viewer_input = _socket_by_name(viewer.inputs, ["Image"], 0)

    if group_output and output_input:
        tree.links.new(group_output, output_input)
    if group_output and viewer_input:
        tree.links.new(group_output, viewer_input)

    return crypto_socket is not None


def _set_group_node_color(scene, group_name, input_name, color):
    tree = _scene_compositor_tree(scene)
    changed = False

    if not tree:
        return False

    for node in tree.nodes:
        if node.bl_idname != "CompositorNodeGroup":
            continue
        if not node.node_tree or node.node_tree.name != group_name:
            continue

        socket = node.inputs.get(input_name)
        if socket and hasattr(socket, "default_value"):
            socket.default_value = color
            changed = True

    group = bpy.data.node_groups.get(group_name)
    if group:
        _set_interface_default(group, input_name, color)

    return changed


def _color_inputs(node):
    return [
        socket
        for socket in node.inputs
        if socket.name != ID_INPUT_NAME and hasattr(socket, "default_value")
    ]


def _randomize_group_input_colors(scene, group_name):
    tree = _scene_compositor_tree(scene)
    changed = False

    if not tree:
        return False

    for node in tree.nodes:
        if node.bl_idname != "CompositorNodeGroup":
            continue
        if not node.node_tree or node.node_tree.name != group_name:
            continue

        sockets = _color_inputs(node)
        if len(sockets) < 2:
            continue

        colors = [tuple(socket.default_value) for socket in sockets]
        random.shuffle(colors)

        for socket, color in zip(sockets, colors):
            socket.default_value = color
            _set_interface_default(node.node_tree, socket.name, color)

        changed = True

    return changed


def _active_object_color(scene, object_name):
    tree = _scene_compositor_tree(scene)

    if tree:
        for node in tree.nodes:
            if node.bl_idname != "CompositorNodeGroup":
                continue
            if not node.node_tree or node.node_tree.name != OBJECT_GROUP_NAME:
                continue

            socket = node.inputs.get(object_name)
            if socket and hasattr(socket, "default_value"):
                return tuple(socket.default_value)

    obj = bpy.data.objects.get(object_name)
    if obj and "object_id_color" in obj:
        saved = obj["object_id_color"]
        if len(saved) == 4:
            return tuple(saved)

    return (1.0, 1.0, 1.0, 1.0)


def parse_shortcut(shortcut_str):
    if not shortcut_str or shortcut_str == "NONE":
        return None, None

    parts = shortcut_str.split()
    if not parts:
        return None, None

    return parts[-1], set(parts[:-1])


def format_shortcut_display(shortcut_str):
    if not shortcut_str or shortcut_str == "NONE":
        return "None"

    key_map = {
        "PERIOD": ".",
        "COMMA": ",",
        "ACCENT_GRAVE": "~",
        "SPACE": "Space",
        "TAB": "Tab",
        "RET": "Enter",
        "RETURN": "Enter",
        "ESC": "Esc",
        "DEL": "Delete",
        "BACK_SPACE": "Backspace",
    }

    display_parts = []
    for part in shortcut_str.split():
        if part == "ALT":
            display_parts.append("Alt")
        elif part == "CTRL":
            display_parts.append("Ctrl")
        elif part == "SHIFT":
            display_parts.append("Shift")
        elif part == "OSKEY":
            display_parts.append("Cmd" if sys.platform == "darwin" else "Win")
        elif part in key_map:
            display_parts.append(key_map[part])
        else:
            display_parts.append(part.replace("_", " ").title())
    return "+".join(display_parts)


def get_shortcut_pref_name(target):
    return f"{target}_shortcut"


def set_shortcut_preference(prefs, target, value):
    setattr(prefs, get_shortcut_pref_name(target), value)


def get_shortcut_preference(prefs, target):
    return getattr(prefs, get_shortcut_pref_name(target))


def redraw_preferences_areas(context):
    screen = getattr(context, "screen", None)
    if not screen:
        return

    for area in screen.areas:
        if area.type == "PREFERENCES":
            area.tag_redraw()


def check_shortcut_conflict(context, shortcut):
    main_key, modifiers = parse_shortcut(shortcut)
    if not main_key:
        return ""

    keyconfig = context.window_manager.keyconfigs.default
    if keyconfig is None:
        return ""

    watched_keymap_names = {name for name, _space_type in SHORTCUT_KEYMAPS}
    for keymap in keyconfig.keymaps:
        if keymap.name not in watched_keymap_names:
            continue

        for item in keymap.keymap_items:
            if item.type != main_key:
                continue

            item_mods = set()
            if item.ctrl:
                item_mods.add("CTRL")
            if item.alt:
                item_mods.add("ALT")
            if item.shift:
                item_mods.add("SHIFT")
            if item.oskey:
                item_mods.add("OSKEY")

            if item_mods == modifiers:
                return f"Already used by {item.name} in {keymap.name}"

    return ""


def register_shortcut(context, operator_idname, shortcut_str):
    main_key, modifiers = parse_shortcut(shortcut_str)
    if not main_key:
        return

    keyconfig = context.window_manager.keyconfigs.addon
    if keyconfig is None:
        return

    for keymap_name, space_type in SHORTCUT_KEYMAPS:
        keymap = keyconfig.keymaps.new(name=keymap_name, space_type=space_type)
        keymap_item = keymap.keymap_items.new(
            operator_idname,
            main_key,
            "PRESS",
            shift="SHIFT" in modifiers,
            ctrl="CTRL" in modifiers,
            alt="ALT" in modifiers,
            oskey="OSKEY" in modifiers,
        )
        addon_keymaps.append((keymap, keymap_item))


def update_shortcut_mapping(context):
    for keymap, keymap_item in addon_keymaps:
        try:
            keymap.keymap_items.remove(keymap_item)
        except Exception:
            pass
    addon_keymaps.clear()

    for target, _label, _default, operator_idname, _icon in SHORTCUT_TARGETS:
        addon = context.preferences.addons.get(__name__)
        shortcut = get_shortcut_preference(addon.preferences, target) if addon else SHORTCUT_DEFAULTS[target]
        register_shortcut(context, operator_idname, shortcut)


class OBJECTID_OT_create(Operator):
    bl_idname = "object_id.create"
    bl_label = "Object ID"
    bl_description = "Enable Object Cryptomatte and create the ObjectID compositor node group"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        view_layer = context.view_layer

        view_layer.use_pass_cryptomatte_object = True
        view_layer.pass_cryptomatte_depth = 2

        objects = _visible_renderable_objects(context)
        if not objects:
            self.report({"WARNING"}, "No visible renderable objects found in the current view layer.")
            return {"CANCELLED"}

        _ensure_scene_compositor_tree(scene)
        _remove_old_group(scene, OBJECT_GROUP_NAME)

        object_names = [obj.name for obj in objects]
        group = _build_id_group(context, OBJECT_GROUP_NAME, object_names, "ViewLayer.CryptoObject")
        has_crypto_socket = _add_group_node_and_links(context, group, "CryptoObject00", 160)

        tree = _scene_compositor_tree(scene)
        if tree:
            tree.update_tag()

        if not has_crypto_socket:
            self.report(
                {"WARNING"},
                "ObjectID was created, but CryptoObject00 was not found on the Render Layers node.",
            )
            return {"FINISHED"}

        self.report({"INFO"}, f"ObjectID created for {len(object_names)} visible objects.")
        return {"FINISHED"}


class OBJECTID_OT_create_material(Operator):
    bl_idname = "object_id.create_material"
    bl_label = "Material ID"
    bl_description = "Enable Material Cryptomatte and create the Material ID compositor node group"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        view_layer = context.view_layer

        view_layer.use_pass_cryptomatte_material = True
        view_layer.pass_cryptomatte_depth = 2

        materials = _visible_materials(context)
        if not materials:
            self.report({"WARNING"}, "No materials found on visible renderable objects.")
            return {"CANCELLED"}

        _ensure_scene_compositor_tree(scene)
        _remove_old_group(scene, MATERIAL_GROUP_NAME)

        material_names = [material.name for material in materials]
        group = _build_id_group(context, MATERIAL_GROUP_NAME, material_names, "ViewLayer.CryptoMaterial")
        has_crypto_socket = _add_group_node_and_links(context, group, "CryptoMaterial00", -120)

        tree = _scene_compositor_tree(scene)
        if tree:
            tree.update_tag()

        if not has_crypto_socket:
            self.report(
                {"WARNING"},
                "Material ID was created, but CryptoMaterial00 was not found on the Render Layers node.",
            )
            return {"FINISHED"}

        self.report({"INFO"}, f"Material ID created for {len(material_names)} visible materials.")
        return {"FINISHED"}


class OBJECTID_OT_change(Operator):
    bl_idname = "object_id.change"
    bl_label = "Change ID"
    bl_description = "Change the selected object's ObjectID input color"
    bl_options = {"REGISTER", "UNDO"}

    color: FloatVectorProperty(
        name="RGB Color",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0, 1.0),
    )

    object_name: StringProperty(options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return context.scene is not None

    def invoke(self, context, _event):
        selected = context.selected_objects
        if len(selected) != 1:
            self.report({"ERROR"}, "Please select exactly one object before using Change ID.")
            return {"CANCELLED"}

        obj = selected[0]
        self.object_name = obj.name
        self.color = _active_object_color(context.scene, obj.name)
        return context.window_manager.invoke_props_popup(self, _event)

    def draw(self, _context):
        self.layout.prop(self, "color", text="Color")

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            self.report({"ERROR"}, "Selected object no longer exists.")
            return {"CANCELLED"}

        color = tuple(self.color)
        obj["object_id_color"] = color

        if not _set_group_node_color(context.scene, OBJECT_GROUP_NAME, obj.name, color):
            self.report({"ERROR"}, "ObjectID node group was not found. Press Object ID first.")
            return {"CANCELLED"}

        return {"FINISHED"}


class OBJECTID_OT_random(Operator):
    bl_idname = "object_id.random"
    bl_label = "Random ID"
    bl_description = "Randomly reorder colors in existing ObjectID and Material ID node groups"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        changed_object = _randomize_group_input_colors(context.scene, OBJECT_GROUP_NAME)
        changed_material = _randomize_group_input_colors(context.scene, MATERIAL_GROUP_NAME)

        if not changed_object and not changed_material:
            self.report({"INFO"}, "No ObjectID or Material ID node group with enough colors was found.")
            return {"CANCELLED"}

        tree = _scene_compositor_tree(context.scene)
        if tree:
            tree.update_tag()

        self.report({"INFO"}, "Random ID colors were reordered.")
        return {"FINISHED"}


class OBJECTID_OT_capture_shortcut(Operator):
    bl_idname = "object_id.capture_shortcut"
    bl_label = "Capture Shortcut"
    bl_options = {"REGISTER", "INTERNAL"}

    target: StringProperty(default="object_id")

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        prefs.capturing_keys = True
        prefs.capture_target = self.target
        prefs.temp_shortcut = ""
        bpy.ops.object_id.capture_shortcut_modal("INVOKE_DEFAULT")
        return {"FINISHED"}


class OBJECTID_OT_capture_shortcut_modal(Operator):
    bl_idname = "object_id.capture_shortcut_modal"
    bl_label = "Capture Shortcut"
    bl_options = {"REGISTER", "INTERNAL"}

    modifier_keys = {
        "LEFT_CTRL",
        "RIGHT_CTRL",
        "LEFT_ALT",
        "RIGHT_ALT",
        "LEFT_SHIFT",
        "RIGHT_SHIFT",
        "OSKEY",
    }
    modifier_map = {
        "LEFT_CTRL": "CTRL",
        "RIGHT_CTRL": "CTRL",
        "LEFT_ALT": "ALT",
        "RIGHT_ALT": "ALT",
        "LEFT_SHIFT": "SHIFT",
        "RIGHT_SHIFT": "SHIFT",
        "OSKEY": "OSKEY",
    }

    def invoke(self, context, _event):
        self.modifiers = set()
        self.main_key = None
        self.waiting_for_confirm = False
        self.confirm_timer = None
        context.window_manager.modal_handler_add(self)
        redraw_preferences_areas(context)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        prefs = context.preferences.addons[__name__].preferences
        if not prefs.capturing_keys:
            self.remove_confirm_timer(context)
            return {"CANCELLED"}

        if event.type in self.modifier_keys:
            self.handle_modifier_event(prefs, event)
        elif event.type not in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "TIMER"}:
            result = self.handle_key_event(context, prefs, event)
            if result is not None:
                redraw_preferences_areas(context)
                return result
        elif event.type == "TIMER" and self.waiting_for_confirm and prefs.temp_shortcut:
            self.finalize_shortcut(context, prefs)
            redraw_preferences_areas(context)
            return {"FINISHED"}

        redraw_preferences_areas(context)
        return {"RUNNING_MODAL"}

    def handle_modifier_event(self, prefs, event):
        modifier = self.modifier_map.get(event.type)
        if not modifier:
            return
        if event.value == "PRESS":
            self.modifiers.add(modifier)
        elif event.value == "RELEASE":
            self.modifiers.discard(modifier)
        self.update_display(prefs)

    def handle_key_event(self, context, prefs, event):
        if event.value == "PRESS":
            if event.type == "ESC":
                prefs.capturing_keys = False
                prefs.temp_shortcut = ""
                self.remove_confirm_timer(context)
                return {"CANCELLED"}

            if event.type == "BACK_SPACE":
                self.set_shortcut_none(context, prefs)
                return {"FINISHED"}

            self.main_key = event.type
            self.update_display(prefs)
            self.remove_confirm_timer(context)
            self.confirm_timer = context.window_manager.event_timer_add(0.1, window=context.window)
            self.waiting_for_confirm = True

        elif event.value == "RELEASE" and self.main_key == event.type and prefs.temp_shortcut:
            self.finalize_shortcut(context, prefs)
            return {"FINISHED"}

        return None

    def update_display(self, prefs):
        parts = sorted(self.modifiers)
        if self.main_key:
            parts.append(self.main_key)
        prefs.temp_shortcut = " ".join(parts)

    def remove_confirm_timer(self, context):
        if self.confirm_timer is not None:
            context.window_manager.event_timer_remove(self.confirm_timer)
            self.confirm_timer = None
        self.waiting_for_confirm = False

    def finalize_shortcut(self, context, prefs):
        shortcut_str = prefs.temp_shortcut
        target = prefs.capture_target
        self.remove_confirm_timer(context)

        conflict = check_shortcut_conflict(context, shortcut_str)
        if conflict:
            prefs.shortcut_conflict = True
            prefs.conflict_info = conflict
            prefs.pending_target = target
            prefs.pending_shortcut = shortcut_str
        else:
            set_shortcut_preference(prefs, target, shortcut_str)
            prefs.shortcut_conflict = False
            prefs.conflict_info = ""
            prefs.pending_target = ""
            prefs.pending_shortcut = ""
            update_shortcut_mapping(context)

        prefs.capturing_keys = False
        prefs.temp_shortcut = ""

    def set_shortcut_none(self, context, prefs):
        set_shortcut_preference(prefs, prefs.capture_target, "NONE")
        prefs.shortcut_conflict = False
        prefs.conflict_info = ""
        prefs.pending_target = ""
        prefs.pending_shortcut = ""
        prefs.capturing_keys = False
        prefs.temp_shortcut = ""
        self.remove_confirm_timer(context)
        update_shortcut_mapping(context)


class OBJECTID_OT_clear_shortcut(Operator):
    bl_idname = "object_id.clear_shortcut"
    bl_label = "Clear Shortcut"
    bl_options = {"REGISTER", "INTERNAL"}

    target: StringProperty(default="object_id")

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        set_shortcut_preference(prefs, self.target, "NONE")
        prefs.shortcut_conflict = False
        prefs.conflict_info = ""
        prefs.pending_target = ""
        prefs.pending_shortcut = ""
        update_shortcut_mapping(context)
        return {"FINISHED"}


class OBJECTID_OT_force_set_shortcut(Operator):
    bl_idname = "object_id.force_set_shortcut"
    bl_label = "Force Set Shortcut"
    bl_options = {"REGISTER", "INTERNAL"}

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        if prefs.pending_target in SHORTCUT_TARGET_IDS and prefs.pending_shortcut:
            set_shortcut_preference(prefs, prefs.pending_target, prefs.pending_shortcut)
            update_shortcut_mapping(context)

        prefs.shortcut_conflict = False
        prefs.conflict_info = ""
        prefs.pending_target = ""
        prefs.pending_shortcut = ""
        self.report({"INFO"}, "Shortcut was set despite the conflict.")
        return {"FINISHED"}


class CRYPTOMATTE_ID_COLOR_Preferences(AddonPreferences):
    bl_idname = __name__

    object_id_shortcut: StringProperty(name="Object ID Shortcut", default=SHORTCUT_DEFAULTS["object_id"])
    material_id_shortcut: StringProperty(name="Material ID Shortcut", default=SHORTCUT_DEFAULTS["material_id"])
    change_id_shortcut: StringProperty(name="Change ID Shortcut", default=SHORTCUT_DEFAULTS["change_id"])
    random_id_shortcut: StringProperty(name="Random ID Shortcut", default=SHORTCUT_DEFAULTS["random_id"])

    capturing_keys: BoolProperty(default=False)
    capture_target: StringProperty(default="")
    temp_shortcut: StringProperty(default="")
    shortcut_conflict: BoolProperty(default=False)
    conflict_info: StringProperty(default="")
    pending_target: StringProperty(default="")
    pending_shortcut: StringProperty(default="")

    def draw_shortcut_row(self, layout, target, label_text, shortcut_value):
        row = layout.row(align=True)
        row.scale_y = 0.6
        split = row.split(factor=0.36, align=True)
        split.label(text=label_text, icon=SHORTCUT_ICONS.get(target, "KEYINGSET"))
        controls = split.row(align=True)

        if self.capturing_keys and self.capture_target == target:
            capture_box = controls.box()
            capture_box.scale_y = 0.6
            capture_row = capture_box.row(align=True)
            capture_row.enabled = False
            capture_row.label(text=format_shortcut_display(self.temp_shortcut) if self.temp_shortcut else "Press keys...")
        else:
            shortcut_box = controls.box()
            shortcut_box.scale_y = 0.6
            shortcut_row = shortcut_box.row(align=True)
            operator = shortcut_row.operator(
                "object_id.capture_shortcut",
                text=format_shortcut_display(shortcut_value),
                emboss=False,
            )
            operator.target = target

        clear_button = controls.operator("object_id.clear_shortcut", text="", icon="X", emboss=False)
        clear_button.target = target

    def draw(self, _context):
        layout = self.layout
        layout.label(text="Use this tool from the Compositor N-panel > Tool tab.", icon="INFO")

        for start in range(0, len(SHORTCUT_TARGETS), 2):
            row = layout.row(align=True)
            for target, label, _default, _operator_idname, _icon in SHORTCUT_TARGETS[start:start + 2]:
                self.draw_shortcut_row(row.column(align=True), target, label, get_shortcut_preference(self, target))

        if self.shortcut_conflict:
            warning_box = layout.box()
            warning_box.alert = True
            warning_box.label(text=f"Shortcut conflict: {self.conflict_info}", icon="ERROR")
            warning_box.operator("object_id.force_set_shortcut", text="Force Set", icon="KEY_HLT")


class CRYPTOMATTE_ID_COLOR_PT_tools(Panel):
    bl_idname = "CRYPTOMATTE_ID_COLOR_PT_tools"
    bl_label = "CryptoMatte ID Color"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Tool"

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space and space.type == "NODE_EDITOR" and space.tree_type == "CompositorNodeTree"

    def draw(self, _context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator("object_id.create", text="Object ID", icon="OBJECT_DATA")
        row.operator("object_id.create_material", text="Material ID", icon="MATERIAL_DATA")

        row = layout.row(align=True)
        row.operator("object_id.change", text="Change ID", icon="COLOR")
        row.operator("object_id.random", text="Random ID", icon="FILE_REFRESH")


classes = (
    CRYPTOMATTE_ID_COLOR_Preferences,
    OBJECTID_OT_create,
    OBJECTID_OT_create_material,
    OBJECTID_OT_change,
    OBJECTID_OT_random,
    OBJECTID_OT_capture_shortcut,
    OBJECTID_OT_capture_shortcut_modal,
    OBJECTID_OT_clear_shortcut,
    OBJECTID_OT_force_set_shortcut,
    CRYPTOMATTE_ID_COLOR_PT_tools,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    update_shortcut_mapping(bpy.context)


def unregister():
    for keymap, keymap_item in addon_keymaps:
        try:
            keymap.keymap_items.remove(keymap_item)
        except Exception:
            pass
    addon_keymaps.clear()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
